Compile main.tex with pdfLaTeX (two or three passes).
This is the complete v7 research revision, not a proof of the general Hodge conjecture.
The new geometric arguments are not Lean-formalised.
