Compile main.tex with pdfLaTeX, three passes.
The complete Hodge version 7 incorporates the Picard construction obstruction and the minimal dimension of a single abelian carrier of the Mumford adjoint structure, with proofs and exact representation checks. The generic mixed link and universal F2 and F3-prime remain open.
The release source tree contains earlier computational and formal-verification materials with their original scope.
