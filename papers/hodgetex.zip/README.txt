Algebraic Hodge Loci and Exceptional Correspondences
Research revision v3.4.1

Compile main.tex with pdfLaTeX at least three times.
Release: https://github.com/creelie/fermat-hodge-/releases/tag/v3.4.1
