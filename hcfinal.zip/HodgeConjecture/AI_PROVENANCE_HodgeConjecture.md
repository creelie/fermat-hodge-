# AI provenance

Paper: *Dense Algebraic Loci of Hodge Classes*, Deep Bhattacharjee and Ushashi Bhattacharya.

## What was done with AI assistance

The constructions on (F2) and (F3'), the search for a closure of the Hodge
conjecture, the text of the paper, the figures, the Lean 4 file and the
Python, Julia, C, C++ and shell programs were carried out by Deep
Bhattacharjee with the help of AI assistance (Claude, Anthropic), in sessions
in the Claude Code environment. The mathematical content was checked as
follows.

* Every hand proof in the paper was read against the cited literature
  (Markman, van Geemen, Schütt, Varesco, Buskin, Bloch, Buchweitz, Flenner,
  Moonen, Zarhin, André, Milne) and the earlier paper of the authors with
  Priyabrata Mandal.
* Every finite quantity (closures of the 256 subsets, Hilbert symbols and
  Hasse invariants, the 165 forms over Q(sqrt 6), the Fricke discriminants
  and Picard numbers, the dimension counts 57, 104 and 26, the Hecke algebra
  dimensions) is recomputed by programs in `code/` in at least two languages
  and the combinatorial and arithmetic ones are proved in
  `lean/HodgeClosure.lean` (sixty-two theorems, fifty-two of them free of
  every axiom, two depending on propext and Quot.sound only, and eight on
  propext only; `native_decide` is not used).
* Two numerical ranks (`product_object.py`, `convolution_checks.py`) are
  computed in floating point; no statement of the paper rests on them. The
  rank behind Theorem VI.6 is also computed exactly (`annihilator_exact.py`),
  the Riemann-Roch polynomial and the thirty-one supports of Proposition VI.7
  (`riemann_roch_pieces.py`), and the invariants of the trace form behind
  Theorem V.14 (`zeta9_invariants.py`), with the Ext groups and chains at the
  CM point of Appendix A (`cm_point_ext.py`, Lean Section 6). A fourth
  round of AI sessions added Lemma VI.9 and Proposition VI.11 (convolutions
  with three line bundles fail at E_0^6); its claim that no Massey product
  had been computed was kept as stated, and the configurations it leaves
  are listed as open in the paper. A fifth round (release v2.0.0) added
  Lemma VI.12 and Proposition VI.13: a lower bound for dim Ext^2 by
  isolated Ext blocks, valid for every twisting cochain, computed over every
  configuration of the four open kinds in a window of twists and shifts
  (`cm_point_counts.py`; the six least values are proved in Lean Section 7
  with a kernel-checked reachability certificate), and Remark V.22 on the
  shape a chain for sqrt 10 would need. The bound settles every placement of
  the thirty-five pieces and two threefolds at one shift meeting along a
  surface; for the other two kinds it is 0 and decides nothing. A sixth
  round added Proposition VI.14 and Corollary VI.15: a threefold piece
  outside every closed chain of Ext blocks fails the criterion for every
  twisting cochain, which settles four line bundles, five line bundles and
  every further piece of positive twist within one shift of the thirty-two
  threefolds (`cm_point_chains.py`; the counts, the entering edges and the
  six-cycles are proved in Lean Section 7). The same round corrected the
  earlier statement that four line bundles are decided by a sixfold Massey
  product: the chain described does not exist when the threefolds have twist
  0, and no closed chain at all exists with four line bundles. The candidate
  configurations (a), (c), (d) and the quotient chains of Proposition V.21
  came from the candidate record of the Anaxia engine of the BLLM project
  (creelie/eBLLM, release v3.0.5, doi:10.5281/zenodo.23469389), whose
  record of configuration (a) carried the same wrong chain; the engine
  proposes, and the proofs and programs decide. The paper now cites the
  engine in a footnote, the bibliography and the data availability section.
  A seventh round added Section VI.G, Setting VI.17 to Remark VI.25,
  with hand proofs throughout: every threefold piece of an object meeting
  the criterion lies on a directed cycle of Ext blocks with exactly one
  edge on which the twisting cochain vanishes, through pieces of both
  parities of shift (Lemma VI.18 to Lemma VI.21); the shape of such cycles
  (Lemma VI.22); and Theorem VI.23, that for every hermitian polarisation
  of E_0^6 a convolution of distinct threefolds and at most five line
  bundles, at any twists, fails the criterion. The enumeration of six,
  seven and eight line bundles (`line_bundle_chains.py`; six and seven
  fail, eight outside thirty-one arrangements, whose ranks the program
  reports) is stated in the paper as a computation of the archive, Remark
  VI.25, and no proved statement rests on it. The enumeration was first
  run on the graph of the engine, as its record C8; its rules were then
  proved in the text and the counts recomputed by the program of the
  archive. An eighth round added Section VI.H, Lemma VI.26 to Proposition
  VI.36, on the support of an object meeting the criterion, with hand
  proofs throughout: the localised Chern character of the support, the
  class of a threefold in local cohomology (Lemma VI.26); the rest of the
  support cuts every threefold of nonzero multiplicity in an ample divisor
  (Theorem VI.27); two threefolds of the same family meeting along a
  surface carry nothing (Theorem VI.29); objects supported on the
  thirty-two threefolds of one family fail (Corollary VI.31); a smooth
  complete intersection cannot carry the rest (Proposition VI.35); an
  ample divisor in the support empties the localised obstruction
  (Proposition VI.36). A ninth round added Lemma VI.32 and Theorem
  VI.33 to the same section: along each line of four threefolds through
  a surface the multiplicities satisfy two linear relations, read off
  from the second summand of the localised obstruction on the surface
  B_j, where the four curves form an ample divisor, so that the
  multiplicities are m a^2; and no object supported on all sixty-four
  threefolds, of both families, has the polarised shape and meets the
  criterion, because the alternating sum of the sixty-four classes is
  zero. The identities of signs and residues used in the section are
  checked by `threefold_supports.py` (sixteen checks). The intersection
  and localisation arguments were proposed in the engine's record C8
  (release v3.1.0, doi:10.5281/zenodo.23484160) and proved in the text;
  the line relations were found in the same engine run on the mixed
  supports that Corollary VI.31 left open.
* A ninth round (release v2.4.0) opened the attack on (F3') beyond the
  square: Proposition V.16 reduces, by Varesco's theorem on the Hodge
  classes of the powers of a K3 surface with totally real endomorphism
  field, the Hodge conjecture for all powers of the surfaces of Section V
  to their exceptional classes (the E-determinant of T); Proposition V.17
  proves (F3') and the Hodge conjecture on every power and Hilbert scheme
  of a K3 surface of Kummer type over Q, that is, whose transcendental
  space embeds in U_Q^3, which is Ma's criterion for dominating a Kummer
  surface, and gives the condition explicitly on the Hasse invariants at
  Picard numbers 17 and 18 by Hasse-Minkowski (the local existence
  conditions for a complement of rank one or two); Remark V.18 records
  that the Fricke surfaces are neither of Kummer type nor in Varesco's two
  families (discriminants 5, 7 against 1, 3), so their exceptional classes
  stay open; and Proposition III.4 records, from Bloch and Srinivas, (F3')
  for fourfolds whose zero-cycles are supported on a threefold. The
  criterion is checked against a direct search in `kummer_type.py`
  (fifteen checks). The literature (Ma 2013, Varesco 2025, Ramon Mari
  2008, Bloch-Srinivas 1983) was read before writing, and the paper
  attributes to it what it proves; the new content is the explicit
  arithmetic condition and the assembly.
* A tenth round (release v2.5.0) took the first of those exceptional
  classes: its Proposition V.17 computed the transcendental spaces of the Fricke
  surfaces as U_Q^2 + <-1> + <-N> by Witt cancellation of the trivial
  lattice from the K3 lattice, so that by Lombardo and van Geemen the
  Kuga-Satake variety is B^4 for an abelian fourfold B of Q(sqrt(-N))-Weil
  type with discriminant one and definite quaternion multiplication, whose
  Hodge group is maximal; Markman's theorem makes the Weil classes of B
  algebraic and Abdulali's theorem (with Schlickewei and van Geemen-Verra)
  the Hodge classes on every power of B, so the Hodge conjecture holds on
  every power of the Kuga-Satake variety; the algebraic locus of the
  exceptional classes over the Fricke family is dense (CM points) and
  either everything or meagre, and the Hodge conjecture on all powers of
  every member follows from the Kuga-Satake correspondence of one very
  general member (Remark V.18 says what that needs: a covering of the
  twisted Fricke surface by a product of curves is not known). Before the
  round the barrier ledger and atlas of the Anaxia engine (creelie/eBLLM
  main at 17d0fa9, after release v3.0.5) were consulted for the Hodge
  walls and routes: no wall stands against the Kuga-Satake route, and the
  route "markman-frontier" lists the exceptional classes as its frontier;
  the hypothesis left open is recorded as a gap in the plan of record. The
  lattice arithmetic is checked in `fricke_lattice.py` (twenty-one
  checks). The literature (Lombardo 2001, van Geemen 2008, Zarhin 1983,
  Abdulali 1999 and 2002, Schlickewei 2010, van Geemen-Verra 2003, Markman
  2023, Varesco 2025) was read before writing and the paper attributes to
  it what it proves; the new content is the identification of the lattice,
  the assembly and the dichotomy. The quaternionic description of the
  Kuga-Satake fourfold, the reduction to one very general member and the
  statement of real multiplication by sqrt 5 and sqrt 7 were wrong and are
  withdrawn in the eleventh round.
* An eleventh round (release v2.6.0) corrected the Fricke families. The
  self-isogeny f of a Fricke surface satisfies (f^*)^2 = -N, not +N:
  Lemma V.8 proves phi_{w(t)} phi_t = [-N] on the universal curve (the
  analytic model z -> z/tau has square [-N], and the comparison sign is
  constant on the connected base), and the sign of (f^*)^2 on the twisted
  surface is -N divided by c(t) c(w(t)), where u(w(t)) = c(t)^2 u(t) is the
  behaviour of the twisting function under the Fricke involution: the pair
  twists (t-p)(t-q), (t-w(p))(t-w(q)) that form the families have
  c(t) c(w(t)) = 1 and give complex multiplication by Q(sqrt -N), the
  fixed-point twists t^2 - N^k have c(t) c(w(t)) = -1 and give the real
  multiplication by sqrt N of the two surfaces of van Geemen and Schutt,
  who state the complex multiplication of the families without proof in
  their Section 7.6. Theorem V.9 then gives the Hodge conjecture on every
  power and Hilbert scheme of every member (Ramon Mari, Varesco) and (F3')
  with it, Remark V.10 states the Picard number 16 of the very general
  member as a computation of the archive (point counts over F_11 and F_7,
  `fricke_picard.py`, twelve checks, the method of the module k3frob of
  the Anaxia engine at commit 8782bd3, which first found that the level-13
  self-map is a complex multiplication), and Proposition V.19 replaces the
  quaternionic Kuga-Satake fourfold by the splitting B ~ E_K x B_3 into a
  CM elliptic curve and a simple threefold with endomorphism field K, by
  the branching of the half-spin representations. The sign is also checked
  by Velu's formulas (`fricke_sign.py`, thirty-two checks; the polynomial
  identity behind lambda(t)^2 = -t^2/N^(k-1) is proved in Lean, three
  theorems). The literature (van Geemen-Schutt 2025 Section 7, Zarhin 1983,
  Varesco 2025, Ramon Mari 2008, Lombardo 2001) was read before writing;
  the new content is the sign lemma, the twist bookkeeping and the
  splitting.
* The theorem on real multiplication by Q(zeta_9)^+ was found in a second
  round of AI sessions and checked against van Geemen and Schütt (2025,
  Sections 4.8 and 5.6), van Geemen (2008, Remark 7.9), Reiner's Maximal
  orders (Theorem 33.15) and Platonov and Rapinchuk (Theorem 7.8). The
  extension to Q(zeta_7)^+ through the Dickson deformation of the family of
  Artebani, Sarti and Taki (2011, Example 6.1 and Table 3), and the
  proposition on where the dihedral mechanism stops, were found in a third
  round; the invariants of the trace form are recomputed in
  `zeta7_invariants.py` and the Dickson identities, the inertness of 2 and
  the sign pattern of the conjugates are proved in Lean.

## What the AI did not do

The AI did not prove (F2), (F3') or the Hodge conjecture; the paper says so
and states at which step each construction stops. No result of the paper is
reported as proved on the strength of a machine computation alone.

## Where the AI was wrong and corrected

During the work three slips were found by the machine checks and corrected
in the text before release: the Hasse invariant at 2 of the form V_2
(it is -1, not +1); the Picard number of the twist family at level 5 (the
base change adds four fibres of type III); and the dimension of the dihedral
Hecke algebra ((n+1)/2, not (n+3)/2).

## Approval

Both authors approved the final version. Funding: none. Competing
interests: none.
