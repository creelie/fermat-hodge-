# Hexagon submission fields

Title: Algebraic Loci of Hodge Classes

Abstract: We prove unconditionally that the Hodge conjecture is equivalent to two statements about abelian varieties, that the locus on which either statement holds is dense in every family and is either the whole family or a meagre set, and that the real multiplications by sqrt 5, sqrt 6, sqrt 7 and by the cubic fields Q(zeta_7)^+ and Q(zeta_9)^+ are algebraic on explicit families of K3 surfaces, the cubic ones on the surfaces of Mumford type whose quaternion algebra is ramified at two real places. For each of the two statements we build the object it needs next, a complex on a product of two Weil fourfolds and a class on an abelian fourteenfold, prove what it does, and prove at which step it stops. Both statements remain open.

Primary subject: math.AG (Algebraic Geometry)
Cross-list subjects: math.NT (Number Theory), math.KT (K-Theory and Homology), math.RT (Representation Theory)
Tags: Hodge conjecture, abelian varieties, Weil classes, K3 surfaces
MSC2020: 14C30 Transcendental methods, Hodge theory (algebro-geometric aspects); 14K20 Analytic theory of abelian varieties; abelian integrals and differentials; 14J28 K3 surfaces and Enriques surfaces; 11E12 Quadratic forms over global rings and fields

Contributor 1 (submitting): Deep Bhattacharjee; ORCID 0000-0003-0466-750X; affiliation: Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India; formerly, University of Calcutta, Kolkata, India; itsdeep@live.com (second address d.bhattacharjee@erl-forschung.de)
Contributor 2: Ushashi Bhattacharya; ORCID 0009-0002-2254-3914; affiliation: Formerly, National Taiwan University, Taipei 106319, Taiwan; rai.bhattacharya.in@gmail.com

Text of the contribution: A mix of human-written and AI-generated.
Human understanding: "All parts" only after both authors have read every proof; otherwise "Some parts, but not all".

Provenance statement: The constructions on the two statements (F2) and (F3'), the search for a closure of the Hodge conjecture, the text, the figures, the Lean 4 file and the Python, Julia, C, C++ and shell programs were carried out by Deep Bhattacharjee with the help of AI assistance (Claude, Anthropic) in the Claude Code environment. Every hand proof was read against the cited literature; every finite quantity in the paper is recomputed by programs in at least two languages, and the combinatorial and arithmetic ones are proved in Lean 4 (forty theorems, thirty-eight free of every axiom). No statement rests on a floating-point computation. The AI did not prove (F2), (F3') or the Hodge conjecture; the paper states at which step each construction stops. Three slips found by the machine checks were corrected before release (a Hasse invariant at 2, a Picard number of a twist family, the dimension of a dihedral Hecke algebra). Both authors approved the final version.

Tools used: Anthropic - Claude (Claude Code); Lean community - Lean 4 (no Mathlib); Python; Julia; C; C++; shell.
Formalization: https://github.com/creelie/fermat-hodge-/blob/main/lean/HodgeClosure.lean (Zenodo DOI of the release once minted; placeholder 10.5281/zenodo.XXXXXXXX)

Source files or ZIP: HodgeConjecture_tex.zip (the folder paper/ with main.tex, the section files, bibliography.tex, declarations.tex and figures/). Do not upload hcfinal.zip or Lean files here.
AI provenance files: AI_PROVENANCE_HodgeConjecture.md
License: CC BY 4.0

Data availability (in the paper): LaTeX source, programs and the Lean 4 file archived at Zenodo under the DOI of the release; repository https://github.com/creelie/fermat-hodge-; the folder preprintHodgeConjecture holds the PDF only.
AI disclosure (in the paper, Data and code availability): Deep Bhattacharjee carried out the constructions on (F2) and (F3') and the Lean, Julia, C, C++, Python and shell verifications with the help of AI assistance (Claude, Anthropic); both authors approved the final version. No separate AI declaration.
Funding: none. Competing interests: none.
Device folder: D:\Hexagon\13 HodgeConjecture.
