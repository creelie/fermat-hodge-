# Hexagon submission fields

Title: Algebraic Loci of Hodge Classes on Abelian Varieties and K3 Surfaces
Authors: Deep Bhattacharjee (corresponding, ORCID 0000-0003-0466-750X, itsdeep@live.com; second address d.bhattacharjee@erl-forschung.de; formerly EGSPL, Bhubaneswar, Odisha 751030, India); Ushashi Bhattacharya (ORCID 0009-0002-2254-3914, rai.bhattacharya.in@gmail.com; formerly National Taiwan University, Taipei 106319, Taiwan)
Primary category: math.AG; cross-lists: math.NT, math.KT
MSC: 14C30 (Transcendental methods, Hodge theory), 14K20 (Analytic theory of abelian varieties), 14J28 (K3 surfaces), 11G15 (Complex multiplication)
Keywords: Hodge conjecture; abelian varieties; Weil classes; K3 surfaces; semiregularity
Abstract: as on the title page of the PDF (one paragraph, "Neither statement is proved").
Data availability: LaTeX source, Python/Julia/C/C++/shell programs and the Lean 4 file are archived at Zenodo under the DOI of the release (placeholder 10.5281/zenodo.XXXXXXXX until minted); repository https://github.com/creelie/fermat-hodge-; the folder preprintHodgeConjecture holds the PDF only.
AI disclosure: Deep Bhattacharjee carried out the constructions and the verifications with the help of AI assistance (Claude, Anthropic); both authors approved the final version.
Funding: none. Competing interests: none.
Lean Zenodo DOI: same record as the code (lean/HodgeClosure.lean, 36 theorems); H8's HodgeObstruction.lean is cited through its own DOI 10.5281/zenodo.23225483.
Device folder: D:\Hexagon\13 HodgeConjecture (to be copied when the device is connected).
