Compile main.tex with pdfLaTeX, three passes.
Complete Hodge version 7, research release v3.1.1.
F2, F3-prime and the general rational Hodge conjecture remain unproved.
Exact finite checks supplement the written proofs; new geometry is not Lean-formalised.
